<script setup>
import FilterSvg from "../../assets/icons/filter-svg-icon.vue";
</script>
<template>
    <button class="btn btn-sm filter_button m-1">
        <FilterSvg color="currentColor" />
        <span class="ms-1 d-600-none">Filter</span>
    </button>
</template>
