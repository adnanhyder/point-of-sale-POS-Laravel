<script setup>
import BinSvg from "../../assets/icons/bin-svg-icon.vue";
</script>
<template>
    <button class="btn btn-sm filter_button m-1">
        <BinSvg color="currentColor" />
        <span class="ms-1 d-600-none">Delete Selected</span>
    </button>
</template>
