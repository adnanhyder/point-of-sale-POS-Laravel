<script setup>
import PlusSvg from "../../assets/icons/plus-svg-icon.vue";
</script>
<template>
    <button class="btn btn-sm add_button m-1">
        <PlusSvg color="#000000" />
        <span class="ms-1 d-600-none">Add New</span>
    </button>
</template>
