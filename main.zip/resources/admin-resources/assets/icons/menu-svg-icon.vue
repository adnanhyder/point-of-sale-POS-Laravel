<script setup>
defineProps({
    color: String,
    background: String,
    width: String,
    height: String,
});
</script>

<template>
    <svg
        :fill="color ?? '#000000'"
        :width="width ?? '30px'"
        :height="height ?? '30px'"
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
    >
        <path d="M3 4H21V6H3V4ZM3 11H21V13H3V11ZM3 18H21V20H3V18Z"></path>
    </svg>
</template>
