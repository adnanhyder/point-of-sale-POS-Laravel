<script setup>
defineProps({
    color: String,
    background: String,
    width: String,
    height: String,
});
</script>

<template>
    <svg
        :width="width ? width : '24px'"
        :height="height ? height : '24px'"
        :fill="'black'"
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        class=""
    >
        <path
            d="M9.24264 18.9964H21V20.9964H3V16.7538L12.8995 6.85431L17.1421 11.0969L9.24264 18.9964ZM14.3137 5.44009L16.435 3.31877C16.8256 2.92825 17.4587 2.92825 17.8492 3.31877L20.6777 6.1472C21.0682 6.53772 21.0682 7.17089 20.6777 7.56141L18.5563 9.68273L14.3137 5.44009Z"
        ></path>
    </svg>
</template>
